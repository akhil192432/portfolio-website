# Portfolio Website

## Overview

This is a full-stack portfolio website built with React (frontend) and Express.js (backend). The application serves as a personal portfolio showcasing projects, skills, and providing a contact form for visitors. It features a modern, responsive design using shadcn/ui components and Tailwind CSS, with server-side GitHub API integration to dynamically display repository information.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The frontend is built with React and uses Vite as the build tool. The application follows a component-based architecture with the following key decisions:

- **Component Library**: Uses shadcn/ui components for consistent, accessible UI elements
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for type-safe form submissions
- **TypeScript**: Full TypeScript support with strict configuration for type safety

The frontend structure includes modular sections (Hero, About, Skills, Projects, Contact) that compose the main portfolio page, with reusable UI components in the shadcn/ui pattern.

### Backend Architecture

The backend is an Express.js server that provides API endpoints and serves the frontend application:

- **API Design**: RESTful API with `/api` prefix for clear separation
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes
- **Logging**: Custom request logging middleware for API endpoints
- **Development Setup**: Vite integration for hot module replacement in development
- **Build Process**: esbuild for efficient server bundling in production

The server handles contact form submissions and acts as a proxy for GitHub API requests to avoid CORS issues.

### Data Storage Solutions

The application uses a hybrid storage approach:

- **Contact Data**: Prepared for PostgreSQL with Drizzle ORM, currently using in-memory storage for development
- **GitHub Data**: Fetched dynamically from GitHub API through server-side proxy endpoints
- **Schema Definition**: Shared TypeScript schemas using Drizzle and Zod for type safety across frontend and backend

The database schema is designed for PostgreSQL with UUID primary keys and timestamp tracking.

### Authentication and Authorization

Currently, the application doesn't implement authentication as it's a public portfolio site. The contact form accepts submissions without user accounts, and GitHub data is public information accessed through the API.

### Design Patterns

- **Monorepo Structure**: Frontend, backend, and shared code in a single repository
- **Shared Types**: Common TypeScript interfaces and Zod schemas in the `shared` directory
- **Component Composition**: React components follow composition patterns with proper prop interfaces
- **Hook Patterns**: Custom React hooks for reusable logic (scrolling, mobile detection, toast notifications)
- **Error Boundaries**: Proper error handling with user-friendly feedback through toast notifications

## External Dependencies

### Third-Party Services

- **GitHub API**: Integrated for dynamic repository and user data fetching through server-side proxy
- **Neon Database**: PostgreSQL database service (configured but not actively used in current implementation)

### Frontend Libraries

- **UI Components**: Radix UI primitives through shadcn/ui for accessible component foundations
- **Styling**: Tailwind CSS with custom design tokens and responsive utilities
- **Icons**: Lucide React for consistent iconography
- **Fonts**: Google Fonts integration (Inter, DM Sans, Fira Code, Geist Mono)
- **Development**: Vite with React plugin and runtime error modal for enhanced development experience

### Backend Libraries

- **Database**: Drizzle ORM with PostgreSQL adapter and connection pooling
- **Validation**: Zod for runtime type checking and schema validation
- **Utilities**: Various Express middleware for JSON parsing, CORS handling, and request logging

### Development Tools

- **TypeScript**: Full TypeScript configuration with strict settings
- **Build Tools**: Vite for frontend, esbuild for backend bundling
- **Code Quality**: ESLint and Prettier (implied by project structure)
- **Database Migrations**: Drizzle Kit for database schema management