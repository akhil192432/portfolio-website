import { GitHubRepo, GitHubUser } from "@shared/schema";

export async function fetchGitHubUser(username: string): Promise<GitHubUser> {
  const response = await fetch(`/api/github/user/${username}`);
  if (!response.ok) {
    throw new Error("Failed to fetch GitHub user");
  }
  return response.json();
}

export async function fetchGitHubRepos(username: string): Promise<GitHubRepo[]> {
  const response = await fetch(`/api/github/user/${username}/repos`);
  if (!response.ok) {
    throw new Error("Failed to fetch GitHub repositories");
  }
  return response.json();
}

export function getLanguageColor(language: string | null): string {
  const colors: Record<string, string> = {
    JavaScript: "#f1e05a",
    TypeScript: "#2b7489",
    Java: "#b07219",
    Python: "#3572A5",
    HTML: "#e34c26",
    CSS: "#1572B6",
    React: "#61dafb",
    "Spring Boot": "#6db33f",
    MySQL: "#4479a1",
  };
  
  return colors[language || ""] || "#6b7280";
}
