import { useRef } from "react";
import { Server, Code, Wrench } from "lucide-react";
import { useIntersectionObserver } from "@/hooks/use-scroll";

interface Skill {
  name: string;
  level: number;
}

interface SkillCategory {
  title: string;
  icon: React.ReactNode;
  color: string;
  skills: Skill[];
}

export function SkillsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const isVisible = useIntersectionObserver(sectionRef, { threshold: 0.3 });

  const skillCategories: SkillCategory[] = [
    {
      title: "Backend",
      icon: <Server className="text-primary text-2xl" />,
      color: "primary",
      skills: [
        { name: "Java Spring Boot", level: 90 },
        { name: "REST APIs", level: 85 },
        { name: "MySQL & JPA", level: 80 },
        { name: "Java", level: 85 },
      ],
    },
    {
      title: "Frontend",
      icon: <Code className="text-accent text-2xl" />,
      color: "accent",
      skills: [
        { name: "HTML/CSS", level: 90 },
        { name: "JavaScript", level: 75 },
        { name: "Responsive Design", level: 85 },
        { name: "UI/UX Design", level: 70 },
      ],
    },
    {
      title: "Tools & Tech",
      icon: <Wrench className="text-slate-600 text-2xl" />,
      color: "slate",
      skills: [
        { name: "Git & GitHub", level: 85 },
        { name: "Maven", level: 75 },
        { name: "Database Design", level: 80 },
        { name: "API Development", level: 85 },
      ],
    },
  ];

  const getProgressBarColor = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-primary";
      case "accent":
        return "bg-accent";
      case "slate":
        return "bg-slate-600";
      default:
        return "bg-primary";
    }
  };

  return (
    <section id="skills" className="py-20 bg-slate-50" ref={sectionRef}>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4" data-testid="skills-title">
            Technical Skills
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto" data-testid="skills-description">
            Full-stack expertise with a focus on Java backend development and modern web technologies
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <div 
              key={category.title} 
              className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 hover:scale-105 hover:rotate-1 cursor-pointer group"
              data-testid={`skill-category-${category.title.toLowerCase()}`}
            >
              <div className="flex items-center mb-6">
                <div className="group-hover:scale-125 group-hover:rotate-12 transition-all duration-300">
                  {category.icon}
                </div>
                <h3 className="text-xl font-semibold text-secondary ml-3 group-hover:text-primary transition-colors duration-300">
                  {category.title}
                </h3>
              </div>
              
              <div className="space-y-6">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skill.name} data-testid={`skill-${skill.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span className="text-sm text-slate-500">{skill.level}%</span>
                    </div>
                    <div className="skill-bar bg-slate-200 rounded-full h-2 hover:h-3 transition-all duration-300">
                      <div 
                        className={`skill-progress ${getProgressBarColor(category.color)} h-2 hover:h-3 rounded-full transition-all duration-500 hover:shadow-lg relative overflow-hidden`}
                        style={{ 
                          width: isVisible ? `${skill.level}%` : "0%",
                          transitionDelay: `${(categoryIndex * 4 + skillIndex) * 0.1}s`
                        }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
