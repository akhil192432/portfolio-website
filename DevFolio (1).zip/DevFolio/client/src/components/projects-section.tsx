import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Github, Star, ExternalLink } from "lucide-react";
import { fetchGitHubRepos, fetchGitHubUser, getLanguageColor } from "@/lib/github";

export function ProjectsSection() {
  const { data: githubUser } = useQuery({
    queryKey: ["/api/github/user", "akhil192432"],
    queryFn: () => fetchGitHubUser("akhil192432"),
  });

  const { data: repositories, isLoading } = useQuery({
    queryKey: ["/api/github/user", "akhil192432", "repos"],
    queryFn: () => fetchGitHubRepos("akhil192432"),
  });

  const featuredProjects = repositories?.slice(0, 6) || [];

  const getProjectImage = (projectName: string) => {
    const images = {
      "Spring-Employee-CRUD": "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      "stylehub-frontend": "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      "Nfl-Spring-App": "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    };
    return images[projectName as keyof typeof images] || "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400";
  };

  const getTechStack = (projectName: string, language: string | null) => {
    const techStacks = {
      "Spring-Employee-CRUD": ["Java", "Spring Boot", "MySQL", "JPA"],
      "stylehub-frontend": ["HTML", "CSS", "JavaScript", "Responsive"],
      "Nfl-Spring-App": ["Java", "Spring Boot", "REST API", "Database"],
    };
    
    return techStacks[projectName as keyof typeof techStacks] || [language || "Code"];
  };

  if (isLoading) {
    return (
      <section id="projects" className="py-20 section-gradient">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">Loading projects...</div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="projects" className="py-20 section-gradient">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4" data-testid="projects-title">
            Featured Projects
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto" data-testid="projects-description">
            A showcase of my recent work in full-stack development, featuring Java Spring Boot applications and modern web solutions
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 hover:bg-primary/5 cursor-pointer" data-testid="stat-repos">
            <div className="text-2xl font-bold text-primary">
              {githubUser?.public_repos || 3}
            </div>
            <div className="text-sm text-slate-600">Public Repos</div>
          </div>
          <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 hover:bg-accent/5 cursor-pointer" data-testid="stat-commits">
            <div className="text-2xl font-bold text-accent">50+</div>
            <div className="text-sm text-slate-600">Commits</div>
          </div>
          <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 hover:bg-secondary/5 cursor-pointer" data-testid="stat-languages">
            <div className="text-2xl font-bold text-secondary">3</div>
            <div className="text-sm text-slate-600">Languages</div>
          </div>
          <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 hover:bg-slate-100 cursor-pointer" data-testid="stat-contributions">
            <div className="text-2xl font-bold text-slate-600">100+</div>
            <div className="text-sm text-slate-600">Contributions</div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProjects.map((project) => (
            <div 
              key={project.id} 
              className="project-card bg-white rounded-xl shadow-lg overflow-hidden group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
              data-testid={`project-${project.name}`}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={getProjectImage(project.name)} 
                  alt={`${project.name} project`}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="flex space-x-2">
                    <a 
                      href={project.html_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-white/90 text-black px-3 py-1 rounded-full text-sm hover:bg-white transition-all duration-200"
                    >
                      View Code
                    </a>
                    {project.homepage && (
                      <a 
                        href={project.homepage} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="bg-primary/90 text-white px-3 py-1 rounded-full text-sm hover:bg-primary transition-all duration-200"
                      >
                        Live Demo
                      </a>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-semibold text-secondary" data-testid={`project-title-${project.name}`}>
                    {project.name.replace(/-/g, ' ')}
                  </h3>
                  <div className="flex items-center text-accent">
                    <Star className="w-4 h-4 mr-1" />
                    <span className="text-sm" data-testid={`project-stars-${project.name}`}>
                      {project.stargazers_count}
                    </span>
                  </div>
                </div>
                
                <p className="text-slate-600 mb-4 text-sm leading-relaxed" data-testid={`project-description-${project.name}`}>
                  {project.description || "No description available"}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {getTechStack(project.name, project.language).map((tech, index) => (
                    <Badge 
                      key={tech} 
                      variant="secondary" 
                      className="tech-tag text-xs hover:scale-110 transition-transform duration-200 cursor-pointer"
                      style={{ 
                        backgroundColor: `${getLanguageColor(tech)}20`, 
                        color: getLanguageColor(tech),
                        animationDelay: `${index * 100}ms`
                      }}
                      data-testid={`tech-${tech.toLowerCase()}`}
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex space-x-3">
                  <a 
                    href={project.html_url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center text-slate-600 hover:text-primary transition-colors duration-200"
                    data-testid={`project-github-${project.name}`}
                  >
                    <Github className="w-4 h-4 mr-2" />
                    <span className="text-sm">View Code</span>
                  </a>
                  {project.homepage && (
                    <a 
                      href={project.homepage} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center text-slate-600 hover:text-accent transition-colors duration-200"
                      data-testid={`project-demo-${project.name}`}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      <span className="text-sm">Live Demo</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button asChild size="lg" data-testid="view-all-projects">
            <a 
              href="https://github.com/akhil192432?tab=repositories" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center"
            >
              <Github className="w-5 h-5 mr-3" />
              View All Projects on GitHub
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
