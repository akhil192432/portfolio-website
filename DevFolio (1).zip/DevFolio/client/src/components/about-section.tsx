import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchGitHubUser } from "@/lib/github";
import { useIntersectionObserver } from "@/hooks/use-scroll";
import profilePhoto from "@assets/WhatsApp Image 2025-08-25 at 9.50.59 PM_1756138898639.jpeg";

function AnimatedCounter({ end, duration = 2000 }: { end: number; duration?: number }) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const inView = useIntersectionObserver(ref, { threshold: 0.5 });

  useEffect(() => {
    if (inView && !isVisible) {
      setIsVisible(true);
      let startTime: number;
      let animationId: number;

      const animate = (currentTime: number) => {
        if (startTime === undefined) startTime = currentTime;
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        setCount(Math.floor(progress * end));
        
        if (progress < 1) {
          animationId = requestAnimationFrame(animate);
        }
      };

      animationId = requestAnimationFrame(animate);
      return () => cancelAnimationFrame(animationId);
    }
  }, [inView, end, duration, isVisible]);

  return (
    <div ref={ref} className="text-2xl font-bold text-primary">
      {count}{end > 10 ? '+' : ''}
    </div>
  );
}

export function AboutSection() {
  const { data: githubUser } = useQuery({
    queryKey: ["/api/github/user", "akhil192432"],
    queryFn: () => fetchGitHubUser("akhil192432"),
  });

  return (
    <section id="about" className="py-20 section-gradient">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="relative group">
              <img 
                src={profilePhoto} 
                alt="Akhil Chowdary Narra - Professional Photo" 
                className="rounded-xl shadow-lg w-full h-auto transition-all duration-500 group-hover:scale-105"
                data-testid="about-image"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          </div>
          
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-6" data-testid="about-title">
              About Me
            </h2>
            <div className="space-y-6 text-lg text-slate-600 leading-relaxed" data-testid="about-content">
              <p>
                I'm a passionate <strong>Full Stack Java Developer</strong> with <strong>2.5+ years</strong> of experience in designing, developing, and deploying scalable web applications. 
                I specialize in <strong>Java Spring Boot</strong>, RESTful API development, and modern frontend technologies like <strong>React</strong>.
              </p>
              <p>
                Currently pursuing my <strong>Master's in Computer Science</strong> at Rivier University while working as a Full Stack Developer at Freyr Solutions. 
                I've contributed to healthcare applications at GE HealthCare, achieving significant performance improvements including <strong>40% reduction in page load times</strong> and <strong>30% optimization in backend response times</strong>.
              </p>
              <p>
                My expertise spans the full development lifecycle - from database design and CI/CD pipeline configuration using Jenkins, 
                to building dynamic React components and implementing secure authentication systems. I'm passionate about clean code, 
                performance optimization, and collaborative development in Agile environments.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-6 mt-8">
              <div className="text-center p-4 bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer" data-testid="projects-stat">
                <AnimatedCounter end={githubUser?.public_repos || 3} />
                <div className="text-sm text-slate-600">Projects</div>
              </div>
              <div className="text-center p-4 bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer" data-testid="experience-stat">
                <div className="text-2xl font-bold text-primary">2.5+</div>
                <div className="text-sm text-slate-600">Years Experience</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
