import { Github, Linkedin, Mail } from "lucide-react";
import { scrollToSection } from "@/hooks/use-scroll";

export function Footer() {
  const quickLinks = [
    { label: "About", href: "about" },
    { label: "Skills", href: "skills" },
    { label: "Projects", href: "projects" },
    { label: "Contact", href: "contact" },
  ];

  return (
    <footer className="bg-secondary text-white py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4" data-testid="footer-brand">Akhil</h3>
            <p className="text-slate-300 leading-relaxed" data-testid="footer-description">
              Full-stack developer passionate about creating robust backend solutions 
              and beautiful user experiences.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4" data-testid="footer-quick-links-title">Quick Links</h4>
            <div className="space-y-2">
              {quickLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => scrollToSection(link.href)}
                  className="block text-slate-300 hover:text-accent transition-colors duration-200 text-left"
                  data-testid={`footer-link-${link.href}`}
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4" data-testid="footer-connect-title">Connect</h4>
            <div className="flex space-x-4">
              <a 
                href="https://github.com/akhil192432/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-slate-300 hover:text-accent transition-all duration-300 hover:scale-125 hover:rotate-12 p-2 rounded-lg hover:bg-accent/10"
                data-testid="footer-github"
              >
                <Github className="w-6 h-6" />
              </a>
              <a 
                href="https://www.linkedin.com/in/akhil-chowdary-narra/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-slate-300 hover:text-accent transition-all duration-300 hover:scale-125 hover:rotate-12 p-2 rounded-lg hover:bg-accent/10"
                data-testid="footer-linkedin"
              >
                <Linkedin className="w-6 h-6" />
              </a>
              <a 
                href="mailto:akhilchowdary342@gmail.com" 
                className="text-slate-300 hover:text-accent transition-all duration-300 hover:scale-125 hover:rotate-12 p-2 rounded-lg hover:bg-accent/10"
                data-testid="footer-email"
              >
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-slate-600 mt-8 pt-8 text-center">
          <p className="text-slate-300" data-testid="footer-copyright">
            &copy; 2024 Akhil. All rights reserved. Built with passion and code.
          </p>
        </div>
      </div>
    </footer>
  );
}
