import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Mail, Github, Linkedin, Download } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { insertContactSchema, type InsertContact } from "@shared/schema";

export function ContactSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState<InsertContact>({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      const validatedData = insertContactSchema.parse(data);
      return apiRequest("POST", "/api/contact", validatedData);
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for your message. I'll get back to you soon.",
      });
      setFormData({ name: "", email: "", subject: "", message: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to send message",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };

  const handleDownloadResume = () => {
    const link = document.createElement('a');
    link.href = '/attached_assets/Akhil Chowdary Narra_Java Full Stack Engineer - Associate_Mavericks_20250725_1756138458895.pdf';
    link.download = 'Akhil_Chowdary_Narra_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({
      title: "Resume downloaded!",
      description: "Thank you for downloading my resume.",
    });
  };

  return (
    <section id="contact" className="py-20 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4" data-testid="contact-title">
            Let's Work Together
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto" data-testid="contact-description">
            Ready to bring your ideas to life? Let's discuss your next project and create something amazing together.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <div className="space-y-8">
              <div className="flex items-center" data-testid="contact-email">
                <div className="bg-primary text-white p-3 rounded-lg mr-4">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-secondary">Email</h3>
                  <p className="text-slate-600">akhilchowdary342@gmail.com</p>
                </div>
              </div>
              
              <div className="flex items-center" data-testid="contact-github">
                <div className="bg-accent text-white p-3 rounded-lg mr-4">
                  <Github className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-secondary">GitHub</h3>
                  <p className="text-slate-600">github.com/akhil192432</p>
                </div>
              </div>
              
              <div className="flex items-center" data-testid="contact-linkedin">
                <div className="bg-blue-600 text-white p-3 rounded-lg mr-4">
                  <Linkedin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-secondary">LinkedIn</h3>
                  <a href="https://www.linkedin.com/in/akhil-chowdary-narra/" target="_blank" rel="noopener noreferrer" className="text-slate-600 hover:text-primary transition-colors">
                    linkedin.com/in/akhil-chowdary-narra
                  </a>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <Button 
                onClick={handleDownloadResume}
                className="w-full md:w-auto bg-secondary hover:bg-slate-700 text-white"
                data-testid="download-resume-btn"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Resume
              </Button>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 border border-transparent hover:border-primary/20">
            <form onSubmit={handleSubmit} className="space-y-6" data-testid="contact-form">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Your full name"
                  className="transition-all duration-300 focus:scale-105 focus:shadow-lg hover:border-primary/50"
                  data-testid="input-name"
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="your.email@example.com"
                  className="transition-all duration-300 focus:scale-105 focus:shadow-lg hover:border-primary/50"
                  data-testid="input-email"
                />
              </div>
              
              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  type="text"
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="Project inquiry"
                  className="transition-all duration-300 focus:scale-105 focus:shadow-lg hover:border-primary/50"
                  data-testid="input-subject"
                />
              </div>
              
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell me about your project..."
                  className="resize-none transition-all duration-300 focus:scale-105 focus:shadow-lg hover:border-primary/50"
                  data-testid="input-message"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-blue-700 hover:scale-105 transition-all duration-300 hover:shadow-lg"
                disabled={contactMutation.isPending}
                data-testid="submit-contact-form"
              >
                <Mail className={`w-4 h-4 mr-2 ${contactMutation.isPending ? 'animate-bounce' : ''}`} />
                {contactMutation.isPending ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
