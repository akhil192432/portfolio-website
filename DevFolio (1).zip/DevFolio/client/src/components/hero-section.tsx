import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, ChevronDown } from "lucide-react";
import { scrollToSection } from "@/hooks/use-scroll";
import profilePhoto from "@assets/WhatsApp Image 2025-08-25 at 9.50.59 PM_1756138898639.jpeg";

export function HeroSection() {
  const [currentTitle, setCurrentTitle] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const titles = ["Full Stack", "Java Developer", "React Expert", "Backend Specialist"];
  const [isTyping, setIsTyping] = useState(true);

  useEffect(() => {
    const typeWriter = () => {
      const title = titles[currentIndex % titles.length];
      if (isTyping) {
        if (currentTitle.length < title.length) {
          setCurrentTitle(title.slice(0, currentTitle.length + 1));
        } else {
          setTimeout(() => setIsTyping(false), 2000);
        }
      } else {
        if (currentTitle.length > 0) {
          setCurrentTitle(currentTitle.slice(0, -1));
        } else {
          setCurrentIndex((prev) => (prev + 1) % titles.length);
          setIsTyping(true);
        }
      }
    };

    const timeout = setTimeout(typeWriter, isTyping ? 150 : 100);
    return () => clearTimeout(timeout);
  }, [currentTitle, currentIndex, isTyping, titles]);

  return (
    <section id="home" className="min-h-screen flex items-center hero-gradient text-white relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <img 
          src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Modern developer workspace" 
          className="w-full h-full object-cover" 
        />
      </div>
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-up">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight" data-testid="hero-title">
              <span className="block">{currentTitle}</span>
              <span className="text-accent block">Developer</span>
              <span className="animate-pulse text-accent">|</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 mb-8 leading-relaxed" data-testid="hero-description">
              Crafting robust backend solutions with <span className="text-accent font-semibold">Java Spring Boot</span> 
              and beautiful frontend experiences. Specialized in REST APIs, database design, and modern web development.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                size="lg"
                onClick={() => scrollToSection("projects")}
                className="bg-primary hover:bg-blue-700 text-white font-semibold transition-all duration-200 hover:scale-105"
                data-testid="view-projects-btn"
              >
                View Projects
              </Button>
              <Button 
                variant="outline"
                size="lg"
                onClick={() => scrollToSection("contact")}
                className="border-2 border-accent text-accent hover:bg-accent hover:text-white font-semibold transition-all duration-200 hover:scale-105"
                data-testid="contact-btn"
              >
                Get In Touch
              </Button>
            </div>
            
            <div className="flex space-x-6">
              <a 
                href="https://github.com/akhil192432/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-slate-300 hover:text-accent transition-colors duration-200"
                data-testid="github-link"
              >
                <Github className="w-6 h-6" />
              </a>
              <a 
                href="https://www.linkedin.com/in/akhil-chowdary-narra/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-slate-300 hover:text-accent transition-colors duration-200"
                data-testid="linkedin-link"
              >
                <Linkedin className="w-6 h-6" />
              </a>
              <a 
                href="mailto:akhilchowdary342@gmail.com" 
                className="text-slate-300 hover:text-accent transition-colors duration-200"
                data-testid="email-link"
              >
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </div>
          
          <div className="hidden md:block animate-fade-in">
            <div className="relative group">
              <img 
                src={profilePhoto} 
                alt="Akhil Chowdary Narra - Full Stack Developer" 
                className="rounded-2xl shadow-2xl w-full max-w-md mx-auto transition-all duration-500 group-hover:scale-105 group-hover:shadow-3xl"
                data-testid="hero-image"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-2xl group-hover:from-accent/30 transition-all duration-300"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-primary to-accent rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity duration-300 -z-10"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce-slow">
        <ChevronDown className="text-accent text-2xl" data-testid="scroll-indicator" />
      </div>
    </section>
  );
}
